USE mydb;

INSERT INTO `mydb`.`proprietarios`
(`id`,
`nome`,
`dataN`,
`profissao`,
`email`,
`telemovel`,
`username`,
`password`)
VALUES
(1,'admin','1995-11-11','admin','admin','admin','admin','admin');
