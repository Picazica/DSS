package dataacess; 

import business.*;
import java.util.Map;
import java.util.Set;
import java.util.Collection;
import java.util.HashSet;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ContaDAO implements Map<String,Conta> {
    
    public Connection conn;
    
    public ContaDAO () {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            this.conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb?useSSL=false", "root", "1234");
        }
        catch (ClassNotFoundException | SQLException e) {}
    }
    
    public void clear () {
        try {
            Statement stm = conn.createStatement();
            stm.executeUpdate("DELETE FROM Contas");
        }
        catch (Exception e) {throw new NullPointerException(e.getMessage());}
    }
    
    public boolean containsKey(Object key) throws NullPointerException {
        try {
            Statement stm = conn.createStatement();
            String sql = "SELECT * FROM Contas WHERE nome='"+(String)key+"'";
            ResultSet rs = stm.executeQuery(sql);
            return rs.next();
        }
        catch (Exception e) {throw new NullPointerException(e.getMessage());}
    }
    
    public boolean containsValue(Object value) {
        throw new NullPointerException("public boolean containsValue(Object value) not implemented!");
    }
    
    public Set<Map.Entry<String,Conta>> entrySet() {
        throw new NullPointerException("public Set<Map.Entry<String,Conta>> entrySet() not implemented!");
    }
    
    public boolean equals(Object o) {
        throw new NullPointerException("public boolean equals(Object o) not implemented!");
    }
    
    public Conta get(Object key) {
        try {
            Conta al = null;
            Statement stm = conn.createStatement();
            String sql = "SELECT * FROM Contas WHERE nome='"+(String)key+"'";
            ResultSet rs = stm.executeQuery(sql);
            if (rs.next())
                al = new Conta(rs.getString(2),rs.getFloat(3));
            return al;
        }catch (Exception e) {throw new NullPointerException(e.getMessage());}
       
    }
    
    public int hashCode() {
        return this.conn.hashCode();
    }
    
    public boolean isEmpty() {
        try {
            Statement stm = conn.createStatement();
            ResultSet rs = stm.executeQuery("SELECT nome FROM Contas");
            return !rs.next();
        }
        catch (Exception e) {throw new NullPointerException(e.getMessage());}
    }
    
    public Set<String> keySet() {
        throw new NullPointerException("Not implemented!");
    }
    
    public Conta put(String key, Conta value) {
        try{
            PreparedStatement pst = conn.prepareStatement("INSERT INTO Contas (nome,total) VALUES (\""+value.getNome()+"\",\""+value.getTotal()+"\");");
            pst.executeUpdate();
            return null;
        }catch (Exception e){throw new NullPointerException(e.getMessage());}
       
    }
    
    public Conta updatePagamento(String key,Conta value){
        try{
            PreparedStatement ps = conn.prepareStatement("UPDATE Contas SET total= ? WHERE nome= ?");
            ps.setFloat(1,value.getTotal());
            ps.setString(2,value.getNome());
            ps.executeUpdate();
            return null;
        }catch (Exception e){throw new NullPointerException(e.getMessage());}
    }
    
    public Conta updatePagamentoAll(float n){
        try{
            PreparedStatement ps = conn.prepareStatement("UPDATE Contas SET total = total - ?");
            ps.setFloat(1,n);
            ps.executeUpdate();
            return null;
        }catch (Exception e){throw new NullPointerException(e.getMessage());}
    }

    public void putSpecial(String key,String valor){
        try{
            Conta c;
            c = get(key);
            float f = c.getTotal()+Float.parseFloat(valor);
            PreparedStatement ps = conn.prepareStatement("UPDATE Contas SET total = ? WHERE nome = ?");
            ps.setFloat(1,f);
            ps.setString(2,key);
            ps.executeUpdate();
        }catch (Exception e){throw new NullPointerException(e.getMessage());}
    
    }

    public void putAll(Map<? extends String,? extends Conta> t) {
        throw new NullPointerException("Not implemented!");
    }
    
    public Conta remove(Object key) {
        try {
            Conta al = this.get(key);
            Statement stm = conn.createStatement();
            String sql = "DELETE FROM Contas WHERE nome=\""+(String)key+"\";";
            stm.executeUpdate(sql);
            return al;
        }
        catch (Exception e) {throw new NullPointerException(e.getMessage());}
    }
    
    public int size() {
        try {
            int i = 0;
            Statement stm = conn.createStatement();
            ResultSet rs = stm.executeQuery("SELECT nome FROM Contas");
            for (;rs.next();i++);
            return i;
        }
        catch (Exception e) {throw new NullPointerException(e.getMessage());}
    }
    
    public Collection<Conta> values() {
        try {
            Collection<Conta> col = new HashSet<Conta>();
            Statement stm = conn.createStatement();
            ResultSet rs = stm.executeQuery("SELECT * FROM Contas");
            for (;rs.next();) {
                col.add(new Conta(rs.getString(2),rs.getFloat(3)));
            }
            return col;
        }
        catch (Exception e) {throw new NullPointerException(e.getMessage());}
    }
    
    public List<String> tableValues(){
        List<String> al= new ArrayList<>();
        try{
            Statement stm = conn.createStatement();
            ResultSet rs = stm.executeQuery("SELECT * FROM Contas");
            while(rs.next()){
                al.add(rs.getString(3));
            }
        }catch (Exception e){throw new NullPointerException(e.getMessage());}
        return al;
    }
    
    public String[] valuesToString(String cod){
        String[] array = new String[3];
        try{
            Statement stm = conn.createStatement();
            ResultSet rs = stm.executeQuery("SELECT * FROM Contas where nome=\""+cod+"\";");
            rs.next();
            array[0] = rs.getString(1);
            for(int i = 1; i < 3; i++) array[i] = rs.getString(i+1);
        }catch (Exception e){throw new NullPointerException(e.getMessage());}
        return array;
    }
    
}