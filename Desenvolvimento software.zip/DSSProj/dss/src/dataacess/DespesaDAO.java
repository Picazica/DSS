package dataacess; 

import business.*;
import java.util.Map;
import java.util.Set;
import java.util.Collection;
import java.util.HashSet;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.text.SimpleDateFormat;
import java.util.Date;


public class DespesaDAO implements Map<Integer,Despesa> {
    
    public Connection conn;

    public DespesaDAO () {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            this.conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb?useSSL=false", "root", "1234");
        }
        catch (ClassNotFoundException | SQLException e) {}
    }
    @Override
    public void clear () {
        try {
            Statement stm = conn.createStatement();
            stm.executeUpdate("DELETE FROM Despesas");
        }
        catch (Exception e) {throw new NullPointerException(e.getMessage());}
    }
    @Override
    public boolean containsKey(Object key) throws NullPointerException {
        try {
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM Despesas WHERE id=?");
            ps.setInt(1, Integer.parseInt((String) key));
            ResultSet rs = ps.executeQuery();
            return rs.next();
        }
        catch (Exception e) {throw new NullPointerException(e.getMessage());}
    }
    @Override
    public boolean containsValue(Object value) {
        throw new NullPointerException("public boolean containsValue(Object value) not implemented!");
    }
    
    @Override
    public Set<Map.Entry<Integer,Despesa>> entrySet() {
        throw new NullPointerException("public Set<Map.Entry<String,Despesa>> entrySet() not implemented!");
    }
    @Override
    public boolean equals(Object o) {
        throw new NullPointerException("public boolean equals(Object o) not implemented!");
    }
  
    public boolean existeDespesa(String descricao){
        try {
            Statement stm = conn.createStatement();
            ResultSet rs = stm.executeQuery("SELECT * FROM Despesas where Descricao=\""+descricao+"\";");
            return(rs.next());
        } catch (Exception e) {throw new NullPointerException(e.getMessage());}
    }
    @Override
    public Despesa get(Object key) {
        try {
            Despesa al = null;
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM Despesas WHERE id=?");
            ps.setInt(1, Integer.parseInt((String) key));
            ResultSet rs = ps.executeQuery();
            if (rs.next()) 
                al = new Despesa(rs.getString(2),rs.getString(3),rs.getFloat(4),rs.getString(5),rs.getString(6),rs.getString(7));
            return al;
        }
        catch (Exception e) {throw new NullPointerException(e.getMessage());}

    }
    @Override
    public int hashCode() {
        return this.conn.hashCode();
    }
    @Override
    public boolean isEmpty() {
        try {
            Statement stm = conn.createStatement();
            ResultSet rs = stm.executeQuery("SELECT descricao FROM Despesas");
            return !rs.next();
        }
        catch (Exception e) {throw new NullPointerException(e.getMessage());}
    }
    
    @Override
    public Set<Integer> keySet() {
        throw new NullPointerException("Not implemented!");
    }
    @Override
    public Despesa put(Integer key, Despesa value) {
        try{
            SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
            Date data = sdf.parse(value.getData());
            java.sql.Date sqlDate = new java.sql.Date(data.getTime());
            PreparedStatement ps = conn.prepareStatement("INSERT INTO Despesas (Descricao,Estado,Valor,Data,Tipo,Inquilino) VALUES (?,?,?,?,?,?)");
            ps.setString(1,value.getDescricao());
            ps.setString(2,value.getEstado());
            ps.setFloat(3,value.getValor());
            ps.setDate(4, sqlDate);
            ps.setString(5,value.getTipo());
            ps.setString(6,value.getInquilino());
            ps.executeUpdate();
            System.out.println("here");
            return null;
        }catch (Exception e){throw new NullPointerException(e.getMessage());}

    }
    
    public Despesa putSpecial(String id,String descricao,String valor,String datan,String inquilino){
        try{
            SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
            Date data = sdf.parse(datan);
            java.sql.Date sqlDate = new java.sql.Date(data.getTime());
            PreparedStatement ps = conn.prepareStatement("UPDATE Despesas SET Descricao=?,Valor=?,Data=?,Inquilino=? WHERE id=?" );
            ps.setString(1,descricao);
            ps.setFloat(2, Float.parseFloat(valor));
            ps.setDate(3, sqlDate);
            ps.setString(4,inquilino);
            ps.setInt(5,Integer.parseInt(id));
            ps.executeUpdate();
            return null;
        }catch (Exception e){throw new NullPointerException(e.getMessage());}

    }
    @Override
    public void putAll(Map<? extends Integer,? extends Despesa> t) {
        throw new NullPointerException("Not implemented!");
    }
    @Override
    public Despesa remove(Object key) {
        try {
            Despesa al = this.get(key);
            Statement stm = conn.createStatement();
            String sql = "DELETE FROM Despesas where id=\""+(Integer)key+"\";";
            stm.executeUpdate(sql);
            return al;
        }
        catch (Exception e) {throw new NullPointerException(e.getMessage());}
    }
    @Override
    public int size() {
        try {
            int i = 0;
            Statement stm = conn.createStatement();
            ResultSet rs = stm.executeQuery("SELECT Descricao FROM Despesas");
            for (;rs.next();i++);
            return i;
        }
        catch (Exception e) {throw new NullPointerException(e.getMessage());}
    }
    @Override
    public Collection<Despesa> values() {
        try {
            Collection<Despesa> col = new HashSet<Despesa>();
            Statement stm = conn.createStatement();
            ResultSet rs = stm.executeQuery("SELECT * FROM Despesas");
            for (;rs.next();) {
                col.add(new Despesa(rs.getString(2),rs.getString(3),rs.getFloat(4),rs.getString(5),rs.getString(6),rs.getString(7)));
            }
            return col;
        }
        catch (Exception e) {throw new NullPointerException(e.getMessage());}
    }
    
    public List<String> tableValues(){
        List<String> al= new ArrayList<>();
        try{
            Statement stm = conn.createStatement();
            ResultSet rs = stm.executeQuery("SELECT * FROM Despesas");
            while(rs.next()){
                al.add(rs.getString(2));
                al.add(rs.getString(1));
                al.add(rs.getString(3));
                al.add(rs.getString(4));
                al.add(rs.getString(5));
                al.add(rs.getString(7));
            }
        }catch (Exception e){throw new NullPointerException(e.getMessage());}
        return al;
    }
    
    public List<String> tableValuesNP(){
        List<String> al= new ArrayList<>();
        try{
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM Despesas WHERE estado=?");
            ps.setString(1,"Não Paga");
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                al.add(rs.getString(2));
                al.add(rs.getString(1));
                al.add(rs.getString(3));
                al.add(rs.getString(4));
                al.add(rs.getString(5));
                al.add(rs.getString(7));
            }
        }catch (Exception e){throw new NullPointerException(e.getMessage());}
        return al;
    }
    

    public String[] valuesToString(int cod){
        String[] array = new String[7];
        try{
            Statement stm = conn.createStatement();
            ResultSet rs = stm.executeQuery("SELECT * FROM Despesas where id=\""+cod+"\";");
            rs.next();
            array[0] = rs.getString(1);
            for(int i = 1; i < 7; i++) array[i] = rs.getString(i+1);
        }catch (Exception e){throw new NullPointerException(e.getMessage());}
        return array;
    }
    
    public Despesa updateEstado(String id){
        try{
            PreparedStatement ps = conn.prepareStatement("UPDATE Despesas SET Estado = ? WHERE id=?");
            ps.setString(1,"Pago");
            ps.setInt(2, Integer.parseInt(id));
            ps.executeUpdate();
            return null;
        }catch (Exception e){throw new NullPointerException(e.getMessage());}
    }
}