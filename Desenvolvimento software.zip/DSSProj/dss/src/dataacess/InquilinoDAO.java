

package dataacess; 

import business.*;
import java.util.Map;
import java.util.Set;
import java.util.Collection;
import java.util.HashSet;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class InquilinoDAO implements Map<String,Inquilino> {
    
    public Connection conn;
    
    public InquilinoDAO (){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            this.conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb?useSSL=false", "root", "1234");
        }
        catch (ClassNotFoundException | SQLException e) {System.out.println("Erro");}
    }
    
    public void clear () {
        try {
            Statement stm = conn.createStatement();
            stm.executeUpdate("DELETE FROM Inquilinos");
        }
        catch (Exception e) {throw new NullPointerException(e.getMessage());}
    }
    
    public boolean containsKey(Object key) throws NullPointerException {
        try {
            Statement stm = conn.createStatement();
            String sql = "SELECT * FROM Inquilinos WHERE nome='"+(String)key+"'";
            ResultSet rs = stm.executeQuery(sql);
            return rs.next();
        }
        catch (Exception e) {throw new NullPointerException(e.getMessage());}
    }
    
    public boolean containsValue(Object value) {
        throw new NullPointerException("public boolean containsValue(Object value) not implemented!");
    }
    
    public Set<Map.Entry<String,Inquilino>> entrySet() {
        throw new NullPointerException("public Set<Map.Entry<String,Inquilino>> entrySet() not implemented!");
    }
    
    public boolean equals(Object o) {
        throw new NullPointerException("public boolean equals(Object o) not implemented!");
    }
    
    public Inquilino get(Object key) {
        try {
            Inquilino al = null;
            Statement stm = conn.createStatement();
            String sql = "SELECT * FROM Inquilinos WHERE nome='"+(String)key+"'";
            ResultSet rs = stm.executeQuery(sql);
            if (rs.next()) 
                al = new Inquilino(rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8));
            return al;
        }
        catch (Exception e) {throw new NullPointerException(e.getMessage());}
    }
    
    public Inquilino getByUsername(String username) {
        try {
            Inquilino al = null;
            Statement stm = conn.createStatement();
            String sql = "SELECT * FROM Inquilinos WHERE username='"+(String)username+"'";
            ResultSet rs = stm.executeQuery(sql);
            if (rs.next()) 
                al = new Inquilino(rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8));
            return al;
        }
        catch (Exception e) {throw new NullPointerException(e.getMessage());}
    }
    
    public int hashCode() {
        return this.conn.hashCode();
    }
    
    public boolean isEmpty() {
        try {
            Statement stm = conn.createStatement();
            ResultSet rs = stm.executeQuery("SELECT nome FROM Inquilinos");
            return !rs.next();
        }
        catch (Exception e) {throw new NullPointerException(e.getMessage());}
    }
    
    public Set<String> keySet() {
        throw new NullPointerException("Not implemented!");
    }
    
    public Inquilino put(String key, Inquilino value) {
        try{
            SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
            Date data = sdf.parse(value.getDataN());
            java.sql.Date sqlDate = new java.sql.Date(data.getTime());
            PreparedStatement pst = conn.prepareStatement("INSERT INTO Inquilinos (nome,dataN,profissao,email,telemovel,username,password) VALUES (\'"+key+"\',?,\'"+value.getProfissao()+"\',\'"+value.getMail()+"\',\'"+value.getTelem()+"\',\'"+value.getUserName()+"\',\'"+value.getPassword()+"\');");
            pst.setDate(1, sqlDate);
            pst.executeUpdate();
            return null;
        }catch (Exception e){throw new NullPointerException(e.getMessage());}
   
    }

    public void putAll(Map<? extends String,? extends Inquilino> t) {
        throw new NullPointerException("Not implemented!");
    }
    
    public Inquilino remove(Object key) {
        try {
            Inquilino al = this.get(key);
            Statement stm = conn.createStatement();
            String sql = "DELETE FROM Inquilinos where nome=\""+(String)key+"\";";
            stm.executeUpdate(sql);
            return al;
        }
        catch (Exception e) {throw new NullPointerException(e.getMessage());}
    }
    
    public int size() {
        try {
            int i = 0;
            Statement stm = conn.createStatement();
            ResultSet rs = stm.executeQuery("SELECT nome FROM Inquilinos");
            for (;rs.next();i++);
            return i;
        }
        catch (Exception e) {throw new NullPointerException(e.getMessage());}
    }
    
    public Collection<Inquilino> values() {
        try {
            Collection<Inquilino> col = new HashSet<Inquilino>();
            Statement stm = conn.createStatement();
            ResultSet rs = stm.executeQuery("SELECT * FROM Inquilinos");
            for (;rs.next();) {
                col.add(new Inquilino(rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8)));
            }
            return col;
        }
        catch (Exception e) {throw new NullPointerException(e.getMessage());}
    }
    
    public boolean existe(String uname,String pword){
        try {
            Statement stm = conn.createStatement();
            ResultSet rs = stm.executeQuery("SELECT * FROM Inquilinos where username=\""+uname+"\" AND password=\""+pword+"\";");
            return(rs.next());
        } catch (SQLException e) {throw new NullPointerException(e.getMessage());}
    }
    
    public boolean existeInquilino(String tele){
        try {
            Statement stm = conn.createStatement();
            ResultSet rs = stm.executeQuery("SELECT * FROM Inquilinos where telemovel=\""+tele+"\";");
            return(rs.next());
        } catch (SQLException e) {throw new NullPointerException(e.getMessage());}
    }
    
    public List<String> tableValues(){
        List<String> al= new ArrayList<>();
        try{
            Statement stm = conn.createStatement();
            ResultSet rs = stm.executeQuery("SELECT * FROM Inquilinos");
            while(rs.next()){
                al.add(rs.getString(2));
                al.add(rs.getString(3));
                al.add(rs.getString(7));
                al.add(rs.getString(6));
            }
        }catch (Exception e){throw new NullPointerException(e.getMessage());}
        return al;
    }
    
    public String[] valuesToString(String cod){
        String[] array = new String[8];
        try{
            Statement stm = conn.createStatement();
            ResultSet rs = stm.executeQuery("SELECT * FROM Inquilinos where id=\""+cod+"\";");
            rs.next();
            array[0] = rs.getString(1);
            array[1] = rs.getString(2);
            array[2] = rs.getDate(3).toString();
            for(int i = 3; i < 8; i++) array[i] = rs.getString(i+1);
        }catch (Exception e){throw new NullPointerException(e.getMessage());}
        return array;
    }
}