package business;

public class Despesa{
    
    private String descricao,estado,data,tipo,inquilino;
    private float valor;
    
    public Despesa(String descricao,String estado,float valor,String data,String tipo,String inquilino){
        this.descricao=descricao;
        this.estado=estado;
        this.valor=valor;
        this.data=data;
        this.tipo=tipo;
        this.inquilino=inquilino;
    }
    
    public String getDescricao(){return this.descricao;}
    public String getEstado(){return this.estado;}
    public float getValor(){return this.valor;}
    public String getData(){return this.data;}
    public String getTipo(){return this.tipo;}
    public String getInquilino(){return this.inquilino;}
    
    public void setDescricao(String s){this.descricao = s;}
    public void setEstado(String s){this.estado = s;}
    public void setValor(float s){this.valor = s;}
    public void setData(String s){this.data=s;}
    public void setTipo(String s){this.tipo=s;}
    public void setInquilino(String s){this.inquilino=s;}
}