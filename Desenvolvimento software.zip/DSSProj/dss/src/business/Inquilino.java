package business;

public class Inquilino{
    
    private String nome,datan,prof,mail,telem,username,password;
    
    public Inquilino(String nome,String datan,String prof,String mail,String telem,String uname,String passwd){
        this.nome = nome;
        this.datan = datan;
        this.prof = prof;
        this.mail = mail;
        this.telem = telem;
        this.username = uname;
        this.password = passwd;
    }
    
    public String getNome(){return this.nome;}
    public String getDataN(){return this.datan;}
    public String getProfissao(){return this.prof;}
    public String getMail(){return this.mail;}
    public String getTelem(){return this.telem;}
    public String getUserName(){return this.username;}
    public String getPassword(){return this.password;}
    
    public void setNome(String s){this.nome = s;}
    public void setDataN(String s){this.datan = s;}
    public void setProfissao(String s){this.prof = s;}
    public void setMail(String s){this.mail = s;}
    public void setTelem(String s){this.telem = s;}
    public void setUserName(String s){this.username = s;}
    public void setPassword(String s){this.password = s;}
}