package business;

public class Conta{
    
    private String nome;
    private float total;
    
    public Conta(String nome,float total){
        this.nome=nome;
        this.total=total;
    }
    
    public String getNome(){return this.nome;}
    public float getTotal(){return this.total;}
    
    public void setNome(String s){this.nome = s;}
    public void setTotal(float s){this.total = s;}
}