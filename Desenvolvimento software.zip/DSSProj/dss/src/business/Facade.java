package business; 

import dataacess.*;
import java.util.List;

public class Facade {
    
    public static boolean loginProprietario(String username, String password){
        ProprietarioDAO dao = new ProprietarioDAO();
        return dao.existe(username, password);
    }

    public static boolean loginInquilino(String username, String password){
        InquilinoDAO dao = new InquilinoDAO();
        return dao.existe(username, password);
    }

    public static boolean loginResponsavel(String username, String password){
        ResponsavelDAO dao = new ResponsavelDAO();
        return dao.existe(username, password);
    }

    
    public static void inserirInquilino(String nome,String datan,String prof,String mail,String telem,String username,String password) throws Exception{
        InquilinoDAO dao = new InquilinoDAO();
        if(dao.existe(username,password)) throw new Exception("Inquilino já existe");
        Inquilino inq = new Inquilino(nome,datan,prof,mail,telem,username,password);
        dao.put(nome, inq);
    }
    
    public static void removerInquilino(String cod)throws Exception{
        InquilinoDAO i = new InquilinoDAO();
        if(! i.containsKey(cod)) throw new Exception();
            i.remove(cod);
        ResponsavelDAO dao= new ResponsavelDAO();
        if(dao.containsKey(cod))
            dao.remove(cod);
        new ContaDAO().remove(cod);
    }
    
    public static List<String> getInquilinoTableValues(){return new InquilinoDAO().tableValues();}

    public static void elegerResponsavel(String cod) throws Exception{
        InquilinoDAO i = new InquilinoDAO();
        if(!i.containsKey(cod)) throw new Exception();
        ResponsavelDAO dao= new ResponsavelDAO();
        dao.clear();
        Inquilino inq= i.get(cod);
        dao.put(cod,inq);
    }


    public static List<String> getDespesasTableValues(){return new DespesaDAO().tableValues();}
    public static List<String> getDespesasTableValuesNP(){return new DespesaDAO().tableValuesNP();}
    
    public static void modificarDespesa(String id,String descricao,String valor,String data,String inquilino){
    	new DespesaDAO().putSpecial(id,descricao,valor,data,inquilino);
    }

    public static void addDespesa(String descricao,String valor,String data,String tipo,String inquilino){
    	float f = Float.parseFloat(valor);
    	Despesa d = new Despesa(descricao,"Não Paga",f,data,tipo,inquilino);
    	new DespesaDAO().put(1,d);
    }


    public static void addConta(String username,String valor){
    	Inquilino i = new InquilinoDAO().getByUsername(username);
    	String nome = i.getNome();
    	new ContaDAO().put(nome,new Conta(nome,Float.parseFloat(valor)));
    }


   public static String getSaldo(String username){
    	Inquilino i = new InquilinoDAO().getByUsername(username);
    	String nome = i.getNome();
    	Conta c= new ContaDAO().get(nome);
    	return String.valueOf(c.getTotal());
    }

    public static void addSaldo(String username,String valor)throws Exception{
    	Inquilino i = new InquilinoDAO().getByUsername(username);
    	String nome = i.getNome();
        ContaDAO cd=new ContaDAO();
        if(!cd.containsKey(nome)) throw new Exception();
    	cd.putSpecial(nome,valor);
    }
    
    public static void fazerPagamento(String id) throws Exception{
        DespesaDAO dd= new DespesaDAO();
        if(!dd.containsKey(id)) throw new Exception();
        Despesa d = dd.get(id);
        if(d.getEstado().equals("Pago")) throw new Exception();
        float f=d.getValor();
        ContaDAO cd = new ContaDAO();
        if(d.getInquilino().equals("todos")){
            float n = f/cd.size();
            List<String> l = cd.tableValues();
            for(String s : l){
                if(Float.parseFloat(s)<n) throw new Exception();
            }
            cd.updatePagamentoAll(n);
        }
        else{
           Conta c= cd.get(d.getInquilino());
           if(c.getTotal()<f) throw new Exception();
           else {
               float n = c.getTotal()-f;
               c.setTotal(n);
               cd.updatePagamento(id, c);
           }
        }
       dd.updateEstado(id);
    }
    
}