Os diagramas de use cases, maquina de estado, sequencia e ainda especifica��o de use cases encontram-se
na pasta "Diagramas de sequencia, use cases, maquina estado, especifica�ao".
Os restantes diagramas encontram-se nas pastas com o nome do respetivo diagrama.